import { useEffect, useMemo, useRef, useState } from "react";
import { ProductCard } from "./ProductCard";
import { Product } from "@/contexts/CartContext";
import { products as fallbackProducts, categoryIcons } from "@/data/products";
import { supabase } from "@/lib/supabase";

const fallbackIcon = "🛒";

function normalizeProduct(row: any): Product {
  const categoryName = row.categorias?.nome || row.categoria || "Outros";

  return {
    id: row.id,
    name: row.nome,
    description: row.descricao || "",
    price: Number(row.preco || 0),
    image: row.imagem_url || "/placeholder.svg",
    category: categoryName,
  };
}

export function ProductGrid() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>(fallbackProducts);
  const [loading, setLoading] = useState(true);
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({});

  useEffect(() => {
    let isMounted = true;

    async function loadProducts() {
      setLoading(true);
      const { data, error } = await supabase
        .from("itens")
        .select(`
          id,
          nome,
          descricao,
          preco,
          categoria,
          imagem_url,
          ativo,
          estoque_atual,
          categoria_id,
          categorias ( nome )
        `)
        .eq("ativo", true)
        .gt("estoque_atual", 0)
        .order("nome", { ascending: true });

      if (!isMounted) return;

      if (error || !data || data.length === 0) {
        console.error("Erro ao carregar itens:", error);
        setProducts(fallbackProducts);
        setLoading(false);
        return;
      }

      setProducts((data as any[]).map(normalizeProduct));
      setLoading(false);
    }

    loadProducts();
    return () => {
      isMounted = false;
    };
  }, []);

  const categories = useMemo(() => {
    return Array.from(new Set(products.map((product) => product.category))).filter(Boolean);
  }, [products]);

  const filteredCategories = activeCategory ? [activeCategory] : categories;

  const scrollToCategory = (cat: string | null) => {
    setActiveCategory(cat);
    if (cat) {
      sectionRefs.current[cat]?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="pb-24">
      <div className="sticky top-0 z-20 bg-background/95 backdrop-blur-sm px-4 py-3 border-b border-border">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          <button
            onClick={() => scrollToCategory(null)}
            className={`shrink-0 px-4 h-9 rounded-full text-sm font-body font-semibold transition-colors ${
              !activeCategory ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground border border-border"
            }`}
          >
            Todos
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => scrollToCategory(cat)}
              className={`shrink-0 px-4 h-9 rounded-full text-sm font-body font-semibold transition-colors flex items-center gap-1.5 ${
                activeCategory === cat ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground border border-border"
              }`}
            >
              <span>{categoryIcons[cat] || fallbackIcon}</span>
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4">
        {loading ? (
          <div className="grid grid-cols-2 gap-3 mt-6">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="bg-card rounded-lg border border-border overflow-hidden animate-pulse">
                <div className="aspect-square bg-muted" />
                <div className="p-3 space-y-2">
                  <div className="h-4 rounded bg-muted" />
                  <div className="h-3 rounded bg-muted w-2/3" />
                  <div className="h-9 rounded-full bg-muted mt-4" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground font-body">Nenhum item disponível no momento.</div>
        ) : (
          filteredCategories.map((category) => (
            <section
              key={category}
              ref={(el) => {
                sectionRefs.current[category] = el;
              }}
              className="mt-6"
            >
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xl">{categoryIcons[category] || fallbackIcon}</span>
                <h2 className="text-lg">{category}</h2>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {products
                  .filter((product) => product.category === category)
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </section>
          ))
        )}
      </div>
    </div>
  );
}
