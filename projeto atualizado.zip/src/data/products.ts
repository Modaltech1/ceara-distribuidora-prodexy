import { Product } from "@/contexts/CartContext";
import cervejaPilsen from "@/assets/products/cerveja-pilsen.jpg";
import cervejaIpa from "@/assets/products/cerveja-ipa.jpg";
import cervejaPuroMalte from "@/assets/products/cerveja-puro-malte.jpg";
import vodka from "@/assets/products/vodka.jpg";
import whisky from "@/assets/products/whisky.jpg";
import gin from "@/assets/products/gin.jpg";
import vinhoTinto from "@/assets/products/vinho-tinto.jpg";
import espumante from "@/assets/products/espumante.jpg";
import refrigerante from "@/assets/products/refrigerante.jpg";
import agua from "@/assets/products/agua.jpg";
import energetico from "@/assets/products/energetico.jpg";
import suco from "@/assets/products/suco.jpg";
import gasP13 from "@/assets/products/gas-p13.jpg";
import gasP45 from "@/assets/products/gas-p45.jpg";
import agua20l from "@/assets/products/agua-20l.jpg";

export const products: Product[] = [
  // Gás
  { id: "g1", name: "Gás de Cozinha P13", description: "Botijão 13kg, entrega rápida", price: 119.90, image: gasP13, category: "Gás" },
  { id: "g2", name: "Gás Industrial P45", description: "Botijão 45kg, uso comercial", price: 399.90, image: gasP45, category: "Gás" },
  // Água
  { id: "a1", name: "Galão de Água 20L", description: "Água mineral, galão retornável", price: 14.90, image: agua20l, category: "Água" },
  { id: "a2", name: "Água Mineral 500ml", description: "Sem gás, purificada", price: 2.50, image: agua, category: "Água" },
  // Cervejas
  { id: "1", name: "Cerveja Pilsen 350ml", description: "Lata gelada, leve e refrescante", price: 4.99, image: cervejaPilsen, category: "Cervejas" },
  { id: "2", name: "Cerveja IPA 473ml", description: "Lata premium, amargor marcante", price: 12.90, image: cervejaIpa, category: "Cervejas" },
  { id: "3", name: "Cerveja Puro Malte 600ml", description: "Garrafa retornável, sabor encorpado", price: 8.50, image: cervejaPuroMalte, category: "Cervejas" },
  // Destilados
  { id: "4", name: "Vodka 1L", description: "Destilada, ideal para drinks", price: 39.90, image: vodka, category: "Destilados" },
  { id: "5", name: "Whisky 12 Anos 750ml", description: "Single malt, envelhecido 12 anos", price: 129.90, image: whisky, category: "Destilados" },
  { id: "6", name: "Gin London Dry 750ml", description: "Botânicos selecionados, seco e aromático", price: 89.90, image: gin, category: "Destilados" },
  // Vinhos
  { id: "7", name: "Vinho Tinto Seco 750ml", description: "Cabernet Sauvignon, corpo médio", price: 34.90, image: vinhoTinto, category: "Vinhos" },
  { id: "8", name: "Espumante Brut 750ml", description: "Borbulhas finas, frutado e elegante", price: 49.90, image: espumante, category: "Vinhos" },
  // Outros
  { id: "9", name: "Refrigerante Cola 2L", description: "Gelado, para acompanhar", price: 7.90, image: refrigerante, category: "Outros" },
  { id: "11", name: "Energético 250ml", description: "Lata, sabor original", price: 8.90, image: energetico, category: "Outros" },
  { id: "12", name: "Suco Natural 1L", description: "Laranja integral, sem conservantes", price: 12.90, image: suco, category: "Outros" },
];

export const categoryOrder = ["Gás", "Água", "Cervejas", "Destilados", "Vinhos", "Outros"];
export const categories = categoryOrder.filter((c) => products.some((p) => p.category === c));

export const categoryIcons: Record<string, string> = {
  "Gás": "🔥",
  "Água": "💧",
  "Cervejas": "🍺",
  "Destilados": "🥃",
  "Vinhos": "🍷",
  "Outros": "🧃",
};
