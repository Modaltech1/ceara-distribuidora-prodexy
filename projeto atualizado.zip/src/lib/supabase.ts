import { createClient } from '@supabase/supabase-js';

const fallbackUrl = 'https://lkwolrsxuhsdnlbfpwkn.supabase.co';
const fallbackAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxrd29scnN4dWhzZG5sYmZwd2tuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMxNjI2OTMsImV4cCI6MjA4ODczODY5M30.dGU3P1EPPCyeXn9KrlfNheAKCl-qfb-xniW8XX0KE04';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || fallbackUrl;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || fallbackAnonKey;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: false,
  },
});

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);
